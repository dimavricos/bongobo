var Base = require('./base');

module.exports = Base.extend({
  url: '/trends/:title',
  idAttribute: 'title'
});
module.exports.id = 'Trend';
