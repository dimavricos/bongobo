var RendrBase = require('rendr/shared/base/model');

module.exports = RendrBase.extend({});
