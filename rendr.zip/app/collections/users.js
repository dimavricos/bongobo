var User = require('../models/user')
  , Base = require('./base');

module.exports = Base.extend({
  model: User,
  url: function(){ 
  	return  "/search/news?v=1.0&q="+this.params.title+"&rsz=8&scoring=d"
  },

  parse: function(response) { 
console.log(JSON.parse(response))
                        return JSON.parse(response).responseData.results;
                    },
});
module.exports.id = 'Users';
