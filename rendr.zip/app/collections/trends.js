var Trend = require('../models/trend')
  , Base = require('./base');

module.exports = Base.extend({
  model: Trend,
  url: function(){ 
  	var country = parseInt(this.params.country)
  	var url = encodeURIComponent('http://www.google.com/trends/hottrends/atom/feed?pn=p')
  	return  "/feed/load?v=1.0&num=-1&q="+url+country
  },
  
  
  parse: function(response) { 
console.log(JSON.parse(response))
                        return JSON.parse(response).responseData.feed.entries;
                    },
                    
});
module.exports.id = 'Trends';
