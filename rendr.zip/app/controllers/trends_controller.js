module.exports = {
  index: function(params, callback) {

    var spec = {
      collection: {collection: 'Trends', params: params}
    };
    this.app.fetch(spec, function(err, result) {
      callback(err, result);
    });
  },

  show: function(params, callback) {
    var spec = {
      model: {model: 'Trend', params: params},
      build: {model: 'Build', params: params}
    };
    this.app.fetch(spec, function(err, result) {
      callback(err, result);
    });
  }
};
