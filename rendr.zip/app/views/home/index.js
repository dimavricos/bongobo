var BaseView = require('../base');

module.exports = BaseView.extend({
  className: 'home_index_view'
});
module.exports.id = 'home/index';
