var BaseView = require('../base');

module.exports = BaseView.extend({
  className: 'users_index_view',

  postRender: function() {
  	
  	console.log(this)
  }



});
module.exports.id = 'users/index';
