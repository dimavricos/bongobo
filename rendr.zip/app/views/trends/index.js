var BaseView = require('../base');

module.exports = BaseView.extend({
  className: 'repos_index_view',
  events : {
  	'click .show' : 'open'

  },

  postRender : function(){
  	console.log(this)
  },

  open: function(e){
  
  }

});
module.exports.id = 'trends/index';
